你好！
这是FuHyMC的已配置好LittleSkin外置登录的HMCL客户端。
FuHyMC用户使用手册：
https://docs.fuhymc.cn/
如果你不是从上述地址下载的此压缩包，请务必访问上述地址获取本服务器详情！