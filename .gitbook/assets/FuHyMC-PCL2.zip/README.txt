欢迎使用FuHyMC服务器专属PCL整合包！
双击Plain Craft Launcher 2.exe即可打开启动器
PCL II的部分功能在此整合包中已被隐藏。
打开PCL启动器后，按F12即可暂时显示被隐藏的功能